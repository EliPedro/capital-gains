﻿namespace CapitalGain.Core.FileProcessor
{
    public class ReaderResult
    {
        public string Content { get; set; }
        public ValidantionProblemDetails Error { get; set; }
    }
}