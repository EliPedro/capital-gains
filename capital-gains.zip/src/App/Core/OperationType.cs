﻿namespace CapitalGain.Core
{
    public static class OperationType
    {
        public const string Buy = "buy";
        public const string Sell = "sell";
    }
}