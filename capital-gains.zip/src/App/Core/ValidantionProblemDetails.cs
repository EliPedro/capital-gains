﻿namespace CapitalGain.Core
{
    public class ValidantionProblemDetails
    {
        public string Title { get; set; }
        public string Detail { get; set; }
    }
}